const fs = require('fs');
function replace(file, find, rep) {
    const content = fs.readFileSync(file, 'utf8');
    fs.writeFileSync(file, content.replace(find, rep));
}
replace('src/components/AppWrapper.tsx', '(event, session)', '(event: any, session: any)');
console.log("Fixed AppWrapper!");
