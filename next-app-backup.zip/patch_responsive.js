const fs = require('fs');

function patchDevicesPage() {
    let content = fs.readFileSync('src/app/iot/devices/page.tsx', 'utf8');
    
    // Header flex
    content = content.replace(
        '<div className="flex justify-between items-center mb-8">',
        '<div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 sm:gap-0 mb-8">'
    );
    
    // Table overflow
    content = content.replace(
        '<div className="bg-neutral-900 rounded-xl border border-neutral-800 overflow-hidden shadow-lg">',
        '<div className="bg-neutral-900 rounded-xl border border-neutral-800 overflow-x-auto shadow-lg">'
    );
    
    // Table min-width to force scrolling if needed
    content = content.replace(
        '<table className="w-full text-left text-foreground">',
        '<table className="w-full text-left text-foreground min-w-[600px]">'
    );

    fs.writeFileSync('src/app/iot/devices/page.tsx', content);
    console.log('Patched devices/page.tsx');
}

function patchDashboardPage() {
    let content = fs.readFileSync('src/app/iot/page.tsx', 'utf8');
    
    // Buttons flex
    content = content.replace(
        '<div className="flex space-x-4">',
        '<div className="flex flex-col sm:flex-row gap-4 sm:space-x-4 sm:gap-0">'
    );

    fs.writeFileSync('src/app/iot/page.tsx', content);
    console.log('Patched iot/page.tsx');
}

function patchDeviceIdPage() {
    let content = fs.readFileSync('src/app/iot/devices/[id]/page.tsx', 'utf8');
    
    // Header title and switch
    content = content.replace(
        '<div className="flex items-center justify-between mb-8">',
        '<div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 sm:gap-0 mb-8">'
    );
    content = content.replace(
        '<div className="flex items-center gap-4 mb-8">',
        '<div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-8">'
    );

    // Tabs overflow
    content = content.replace(
        '<div className="flex items-center gap-6 mb-8 border-b border-panel-border">',
        '<div className="flex items-center gap-6 mb-8 border-b border-panel-border overflow-x-auto whitespace-nowrap pb-1">'
    );

    // Photoperiod inputs
    content = content.replace(
        '<div className="grid grid-cols-2 gap-4">',
        '<div className="grid grid-cols-1 sm:grid-cols-2 gap-4">'
    );
    
    // Schedule inputs
    content = content.replace(
        '<div className="flex items-end gap-4 max-w-2xl">',
        '<div className="flex flex-col sm:flex-row items-stretch sm:items-end gap-4 max-w-2xl">'
    );

    // Rules inputs
    content = content.replace(
        '<div className="grid grid-cols-5 items-end gap-4">',
        '<div className="grid grid-cols-1 sm:grid-cols-5 items-end gap-4">'
    );
    content = content.replace(
        '<div className="col-span-1">',
        '<div className="col-span-1 sm:col-span-1">'
    );
    content = content.replace(
        '<div className="col-span-2">',
        '<div className="col-span-1 sm:col-span-2">'
    );
    
    // Tables
    content = content.replace(
        /<table className="min-w-full divide-y divide-zinc-800">/g,
        '<table className="min-w-[500px] sm:min-w-full divide-y divide-zinc-800">'
    );
    content = content.replace(
        /<div className="bg-panel-base backdrop-blur-md border border-panel-border rounded-xl overflow-hidden">/g,
        '<div className="bg-panel-base backdrop-blur-md border border-panel-border rounded-xl overflow-x-auto">'
    );

    fs.writeFileSync('src/app/iot/devices/[id]/page.tsx', content);
    console.log('Patched devices/[id]/page.tsx');
}

try {
    patchDevicesPage();
    patchDashboardPage();
    patchDeviceIdPage();
    console.log('All patches applied successfully!');
} catch (e) {
    console.error('Error patching:', e);
}
