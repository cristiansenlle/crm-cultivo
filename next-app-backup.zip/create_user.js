const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://opnjrzixsrizdnphbjnq.supabase.co', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9wbmpyeml4c3JpemRucGhiam5xIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MjU3NzY1MCwiZXhwIjoyMDg4MTUzNjUwfQ.8X-hxKbCkjxZ5dBXa9_ZefQW0QpIe1RZSp0kNVfst5Y');
supabase.auth.admin.createUser({
  email: 'cristiansenlle@gmail.com',
  password: 'Fn@calderon6193',
  email_confirm: true
}).then(res => {
  if (res.error) console.error('Error:', res.error.message);
  else console.log('User created:', res.data.user.id);
}).catch(console.error);
