const fs = require('fs');
function replace(file, find, rep) {
    const content = fs.readFileSync(file, 'utf8');
    fs.writeFileSync(file, content.replace(find, rep));
}
replace('src/app/analytics/page.tsx', '((a: any, b: any)=>', '(a: any, b: any)=>');
replace('src/components/dashboard/DashboardOverview.tsx', '((payload: any)', '(payload: any)');
console.log("Fixed syntax!");
