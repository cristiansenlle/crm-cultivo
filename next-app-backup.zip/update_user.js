const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://opnjrzixsrizdnphbjnq.supabase.co', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9wbmpyeml4c3JpemRucGhiam5xIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MjU3NzY1MCwiZXhwIjoyMDg4MTUzNjUwfQ.8X-hxKbCkjxZ5dBXa9_ZefQW0QpIe1RZSp0kNVfst5Y');
supabase.auth.admin.listUsers().then(async ({data, error}) => {
  const user = data.users.find(u => u.email === 'cristiansenlle@gmail.com');
  if (user) {
    const res = await supabase.auth.admin.updateUserById(user.id, { password: 'Fn@calderon6193', email_confirm: true });
    if (res.error) console.error('Error updating:', res.error);
    else console.log('Password updated for existing user');
  } else {
    console.log('User not found in list');
  }
});
