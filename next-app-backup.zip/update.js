﻿const fs = require('fs');
const path = 'c:/Users/Cristian/.gemini/antigravity/crm cannabis/next-app/src/app/iot/devices/[id]/page.tsx';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
    const [activeTab, setActiveTab] = useState<'control' | 'schedules' | 'rules' | 'settings'>('control');,
    const [activeTab, setActiveTab] = useState<'control' | 'schedules' | 'rules' | 'settings'>('control');

  const [allDevices, setAllDevices] = useState(Object.values(MOCK_DEVICES));

  useEffect(() => {
    Object.values(MOCK_DEVICES).forEach((dev) => {
      fetch('/api/iot/shelly', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deviceId: dev.deviceId, action: 'status' })
      })
      .then(res => res.json())
      .then(data => {
        if (data.success && data.result?.device_info?.name) {
          setAllDevices(prev => prev.map(d => 
            d.deviceId === dev.deviceId ? { ...d, name: data.result.device_info.name } : d
          ));
        }
      })
      .catch(() => {});
    });
  }, []);
);

content = content.replace(
    const createPhotoperiod = async () => {
    setLoading(true);
    const scriptName = \Photoperiod_\\;,
    const createPhotoperiod = async () => {
    setLoading(true);
    const scriptName = \Photoperiod_\hON_\hOFF_\\;
);

content = content.replace(
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'rules' && (,
                  ))}
              </tbody>
            </table>
          </div>

          <div className="bg-panel-base backdrop-blur-md border border-panel-border rounded-xl p-6 mt-6 overflow-x-auto">
            <h2 className="text-xl font-semibold mb-4">Fotoperíodos Activos</h2>
            <table className="min-w-[500px] sm:min-w-full divide-y divide-zinc-800">
              <thead className="bg-background/50"><tr><th className="px-6 py-3 text-left text-xs font-medium text-foreground/60 dark:text-foreground/60 uppercase">Configuración</th><th className="px-6 py-3 text-left text-xs font-medium text-foreground/60 dark:text-foreground/60 uppercase">Estado</th><th className="px-6 py-3 text-right text-xs font-medium text-foreground/60 dark:text-foreground/60 uppercase">Opciones</th></tr></thead>
              <tbody className="divide-y divide-zinc-800">
                {scripts.filter(s => s.name.startsWith('Photoperiod_')).map((s) => {
                  const match = s.name.match(/^Photoperiod_([0-9.]+)hON_([0-9.]+)hOFF_/);
                  const info = match ? \\hs ON / \hs OFF\ : s.name;
                  return (
                  <tr key={s.id} className="hover:bg-panel-border/30">
                    <td className="px-6 py-4 text-sm font-medium text-foreground">{info}</td>
                    <td className="px-6 py-4 text-sm"><span className={\px-2 py-1 rounded text-xs \\}>{s.running ? 'Activo' : 'Detenido'}</span></td>
                    <td className="px-6 py-4 text-right"><button onClick={() => deleteScript(s.id)} className="text-red-500 hover:text-red-400 text-sm font-medium">Eliminar</button></td>
                  </tr>
                )})}
                {scripts.filter(s => s.name.startsWith('Photoperiod_')).length === 0 && <tr><td colSpan={3} className="px-6 py-8 text-center text-foreground/50 text-sm">No hay fotoperíodos configurados.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'rules' && (
);

content = content.replace(
  {Object.values(MOCK_DEVICES).map(d => <option key={d.id} value={d.deviceId}>{d.name} ({d.deviceId})</option>)},
  {allDevices.map(d => <option key={d.id} value={d.deviceId}>{d.name} ({d.deviceId})</option>)}
);

content = content.replace(
                <tbody className="divide-y divide-zinc-800">
                {scripts.map((s) => (,
                <tbody className="divide-y divide-zinc-800">
                {scripts.filter(s => !s.name.startsWith('Photoperiod_')).map((s) => (
);

content = content.replace(
  {scripts.length === 0 && <tr><td colSpan={3} className="px-6 py-8 text-center text-foreground/50 text-sm">No hay reglas configuradas.</td></tr>},
  {scripts.filter(s => !s.name.startsWith('Photoperiod_')).length === 0 && <tr><td colSpan={3} className="px-6 py-8 text-center text-foreground/50 text-sm">No hay reglas configuradas.</td></tr>}
);

fs.writeFileSync(path, content, 'utf8');
console.log('File updated successfully.');
