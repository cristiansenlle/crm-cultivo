const fs = require('fs');
function replace(file, find, rep) {
    const content = fs.readFileSync(file, 'utf8');
    fs.writeFileSync(file, content.replace(find, rep));
}
replace('src/app/api/iot/shelly/route.ts', 'let result;', 'let result: any;');
replace('src/components/PhotoperiodChartModal.tsx', '(log) =>', '(log: any) =>');
console.log("Fixed last two!");
