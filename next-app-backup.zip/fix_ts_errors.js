const fs = require('fs');
function replace(file, find, rep) {
    const content = fs.readFileSync(file, 'utf8');
    fs.writeFileSync(file, content.replace(find, rep));
}
replace('src/app/analytics/page.tsx', '(a,b)=>', '((a: any, b: any)=>');
replace('src/app/analytics/page.tsx', 'q =>', '(q: any) =>');
replace('src/app/api/iot/shelly/route.ts', '...body,', '...(body || {}),');
replace('src/app/api/iot/shelly/route.ts', "shelly.callRpc('Shelly.GetStatus');", "shelly['callRpc']('Shelly.GetStatus');");
replace('src/app/api/iot/shelly/route.ts', 'shelly.callRpc', "shelly['callRpc']");
replace('src/app/cultivo/CultivoView.tsx', 'b =>', '(b: any) =>');
replace('src/app/cultivo/CultivoView.tsx', 'ev =>', '(ev: any) =>');
replace('src/app/cultivo/CultivoView.tsx', 's =>', '(s: any) =>');
replace('src/app/tareas/NativeCalendar.tsx', 'b =>', '(b: any) =>');
replace('src/components/dashboard/DashboardOverview.tsx', '(payload)', '((payload: any)');
replace('src/components/PhotoperiodChartModal.tsx', 'log =>', '(log: any) =>');
console.log("Replaced!");
